/*
 * Working Clock.c
 *
 * Created: 20-06-2019 02:09:15
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	
	//Beklow is the code for working Clock
	
	//_delay_ms(1) is used so as to display all digit simultaneously  
	
	//if delay is kept very high then the we wont be able to see all digits simultaneously
	
	
    /* Replace with your application code */
	unsigned char a[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67};//Setting up the codes for digits from (0 - 9)
		
	//Below variables for loops
	unsigned int i;//This is just to cause delay so as to avoid distortion
    unsigned int j;//Lower Second loop
	unsigned int k;//Higher Second loop
	unsigned int l;//Lower Minute Loop
	unsigned int m;//Higher Minute Loop
	unsigned int n;//Lower Hour loop
	unsigned int o;//Higher Hour Loop
	DDRA=0xFF;//For minute
	DDRC=0xFF;//For Second
	DDRD=0xFF;//Set up for the digits
	DDRB=0xFF;//For Hour
while (1) 
  //60  59   20   19  | 21,22,23,24  
  
  //Will divide code into two parts
  
  //20 hours + 4hours 
  
  //Code for 20 hours begin here
  
  {
 for(o=0;o<=1;o++)  
	 {
	   for(n=0;n<=9;n++)
		  {   
			  for(m=0;m<=5;m++)
			  {		  
				for(l=0;l<=9;l++)
				  { 
                       for(k=0;k<=5;k++)
                                 {
	                                for(j=0;j<=9;j++)
	                                    {
	                                        for(i=0;i<=100;i++)
		                                        { 
	 
	                                                     //For Second
														  
                                            		      PORTD=1<<5;
                                            		      PORTC=a[k];
                                            		      _delay_ms(1); 
                                            		      
                                            		      PORTD=1<<4;
                                            		      PORTC=a[j];
                                            		      _delay_ms(1);
													     
														 //For Minute
														 	  
														  PORTD=1<<3;
														  PORTA=a[m];
														  _delay_ms(1);
														  
														  
														  PORTD=1<<2;
														  PORTA=a[l];
														  _delay_ms(1);		
														  
														  //For Hour
														  
														   PORTD=1<<1;
														   PORTB=a[n];
														   _delay_ms(1);
														   
														   PORTD=1<<0;
														   PORTB=a[o];
														   _delay_ms(1);												  
		                                        }
	                                   }
                    
					              }
								  
				  }
			  }
		  }
	 }
//Code for 20 hours end here
	 
//After 20 hours of completion

//21 - 24 will be carried by single hour loop because
//2 is constant here 


   for(n=0;n<=9;n++)
		  {   
			  for(m=0;m<=5;m++)
			  {		  
				for(l=0;l<=9;l++)
				  { 
                       for(k=0;k<=5;k++)
                                 {
	                                for(j=0;j<=9;j++)
	                                    {
	                                        for(i=0;i<=100;i++)
		                                        { 
	
                                            		      PORTD=1<<5;
                                            		      PORTC=a[k];
                                            		      _delay_ms(1);
                                            		      
                                            		      PORTD=1<<4;
                                            		      PORTC=a[j];
                                            		      _delay_ms(1);
														  
														  PORTD=1<<3;
														  PORTA=a[m];
														  _delay_ms(1);
														  
														  
														  PORTD=1<<2;
														  PORTA=a[l];
														  _delay_ms(1);		
														  
														   PORTD=1<<1;
														   PORTB=a[n];
														   _delay_ms(1);
														   
														   PORTD=1<<0;
														   PORTB=a[2];
														   _delay_ms(1);												  
		                                        }
	                                   }
                    
					      }
								  
				  }
			  }
		  }
	//Code for 4 hours duration ends here
    }
}

