/*
 * Basic Keypad.c
 *
 * Created: 14-06-2019 23:48:01
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{

    /* Replace with your application code */
	//PIN to read the data
	
		DDRA=0xFF;//row output
		DDRC=0;//column input
		DDRB=0xFF;//BULB
		PORTB=0;
		PORTA = 0xFF;
		PORTC=0xFF;
    while (1) 
    {
      //R1 =0            //Column is input  // 1<<0
	PORTA = 0xFE;
		if((PINC==0xFE))//Pin 3 =0  ----- ----1
		{
			PORTB=1<<0;
			
			PORTB=0;
			PORTC=0xFF;
		}
		else if ((PINC==0xFD))
		{
			PORTB=1<<1;
			PORTB=0;
			
			PORTC=0xFF;
		}

    }
}

