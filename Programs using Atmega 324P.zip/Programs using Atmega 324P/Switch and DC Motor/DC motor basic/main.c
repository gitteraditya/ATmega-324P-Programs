/*
 * DC motor basic.c
 *
 * Created: 18-06-2019 02:27:32
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
    /* Replace with your application code */
	DDRB=0xFF;
	PORTB=0;
	DDRD=0;
		DDRA=0;
		DDRC=0;
    while (1) 
    {
       if(((PINC)&(0x02))==0x02) //2  Switch
		{
			PORTB = PORTB | 1<<1;//MOTOR
			//to make 0. PORTB = (PORTB) & (~(1<<0))..For making it off particular pin
		}
       else if(((PINC)&(0x01))==0x01)//1 Switch
       {
			PORTB = PORTB | 1<<0;//MOTOR
       }		
    }
}

