/*
 * Traffic Light.c
 *
 * Created: 12-06-2019 14:58:52
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>
int main(void)
{
    /* Replace with your application code */
	unsigned char i;
	unsigned char j;
	unsigned int k=0;
	DDRB = 0xFF;
    while (1) 
    {
	  for(i=0;i<=40;i++)
	  {k=0;
		  for(j=0;j<=40;j++)
		  {
			  k=k+1;
		  }
	  }
	  PORTB = 0x01;
	  _delay_ms(500);
	  PORTB = 1<<1;
	  _delay_ms(500);
	  PORTB = 1<<2;
	  _delay_ms(500);	  
    }
	return 0;
}

