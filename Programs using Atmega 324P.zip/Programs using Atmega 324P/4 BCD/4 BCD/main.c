/*
 * 7 Segment Basic.c
 *
 * Created: 13-06-2019 02:34:13
 * Author : hp
 */ 

#include <avr/io.h>

#include<util/delay.h>
int main(void)
{
	unsigned char a[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67};//Learn it Cathode Method
		unsigned char i;
		DDRB = 0xFF;//BCD OUTPUT
		DDRD = 0xFF;//BCD CONTROL
    /* Replace with your application code */
    while (1) 
    {
		//keeping both Active
					PORTD=1<<0;//1 digit
					PORTB= a[0];
		            _delay_ms(1);
					PORTD=1<<1;//2 digit
					PORTB= a[2];
				    _delay_ms(1);
					PORTD=1<<2;//3 digit
					PORTB= a[4];
					_delay_ms(1);
					PORTD=1<<3;//4 digit
					PORTB= a[6];
					_delay_ms(1);			
    }
}

