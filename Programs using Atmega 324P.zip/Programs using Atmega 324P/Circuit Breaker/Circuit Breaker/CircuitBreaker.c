/*
 * 7 Segment Basic.c
 *
 * Created: 13-06-2019 02:34:13
 * Author : hp
 */ 

#include <avr/io.h>

#include<util/delay.h>
int main(void)
{
	        unsigned char a[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67};//Learn it Cathode Method
			unsigned int j=0;
			unsigned int k=0;
			
			
		//The Password for the Circuit is is 341288190  
		//Each key should be pressed after 2 seconds and proceed further only if The pressed key is displayed on 7 Segment
		
			
		//Defining Variables for Password Matcher
		

		//Defining Keypad
		
		//In the keypad the last row is not used
		
		
		DDRA=0xFF;//row output
		DDRC=0;//column input
		
		DDRB=0xFF;//BULB
		PORTB=0;
		
		PORTA=0xFF;
		PORTC=0xFF;
		
		//Defining 7 Segment 
		//Used to show the pressed key
		DDRD=0xFF;
		PORTD=0x00;
		
		unsigned int b[]= {0,0,0,0,0,0,0,0,0} ;//Array used for password verification
			
		unsigned int i=-1;
		//i used to fill the pressed buttons in array 
		//Outside while(1) so that i does not get reset always
		
		//Program 
    while(1)
    {
	 //Code for Circuit Breaker
	 
	 	
        //Code for 1st Row starts here            //Column is input  // 1<<0
	    PORTA = 0xFE;//1 Row Selected
		if((PINC==0xFE))//Column 1
		{
			PORTD=a[1];
			PORTC=0xFF;
			i=i+1;
			//b[i]=1;
			b[i]=1;
			_delay_ms(1000);
			
		}
		else if ((PINC==0xFD))//Column 2
		{
			PORTD=a[2];
			PORTC=0xFF;
			i=i+1;
			//b[i]=2;
		
			b[i]=2;
			_delay_ms(1000);
		}
		else if ((PINC==0xFB))//Column 3
		{
			PORTD=a[3];
			PORTC=0xFF;
			i=i+1;
			//b[i]=3;

			b[i]=3;
			_delay_ms(1000);
		}
		
		//The Code for 2nd Row starts here
		
		PORTA = 0xFD;//For R2=0
		if ((PINC==0xFE))
		{
			PORTD=a[4];
			PORTC=0xFF;
			i=i+1;
	
			b[i]=4;
			_delay_ms(1000);
		}
		else if ((PINC==0xFD))
		{
			PORTD=a[5];
			PORTC=0xFF;
			i=i+1;

			b[i]=5;
			_delay_ms(1000);
		}
		else if ((PINC==0xFB))
		{
			PORTD=a[6];
			PORTC=0xFF;
			i=i+1;
	
			b[i]=6;
			_delay_ms(1000);
		}
		
		
		//The Code for 3rd Row begins here
		
		
		PORTA = 0xFB;//For R3=0
		if ((PINC==0xFE))
		{
			PORTD=a[7];
			PORTC=0xFF;
			i=i+1;
			
			b[i]=7;
			_delay_ms(1000);
		}
		else if ((PINC==0xFD))
		{
			PORTD=a[8];
			PORTC=0xFF;
			i=i+1;
		
			b[i]=8;
			_delay_ms(1000);
		}
		else if ((PINC==0xFB))
		{
			PORTD=a[9];
			PORTC=0xFF;
			i=i+1;
	
			b[i]=9;
			_delay_ms(1000);
		}
		
		//The Code for keypad ends here
		
		
		//Below Code checks the Passwords
		
		if((b[0]==3) & (b[1]==4) & (b[2]==1) & (b[3]==2) & (b[4]==8) & (b[5]==8) & (b[6]==1) & (b[7]==9) & (b[8]==0))  //(b[0]==1) & (b[1]==2) & (b[2]==3)
		{
			PORTB = 0xFF;
			_delay_ms(1000);
		
		}
		
	}
}