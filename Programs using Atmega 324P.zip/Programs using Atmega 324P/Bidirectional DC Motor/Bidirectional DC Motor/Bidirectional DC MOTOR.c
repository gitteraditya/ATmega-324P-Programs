/*
 * Bidirectional DC Motor.c
 *
 * Created: 22-06-2019 01:16:11
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRB=0xFF;//Taking the OR Gates Output as output
	PORTB=0;
    /* Replace with your application code */
    while (1) 
    {
		PORTB = 1<<0;      //To move the rotor in clockwise direction
		_delay_ms(3000);
		PORTB = 1<<1;      //To move the rotor in anti - clockwise direction
		_delay_ms(4000);
    }
}

