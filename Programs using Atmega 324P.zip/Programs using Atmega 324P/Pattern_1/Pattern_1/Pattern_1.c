/*
 * DOT MATRIX Printing Character.c
 *
 * Created: 15-06-2019 16:44:00
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>

//Delay function created

void k(int d)
{
	unsigned int i;
	unsigned int j;
  for(i=0;i<=10;i++)
  {
	  for(j=0;j<=d;j++)
	  {  
	  }
  } 
}
void pattern(int x)

//Here is the pattern which will be running

//All columns are selected so in different row every column would be displayed simultaneously

//The row which is skipped would be displayed

//k(x) to call delay which will be varied to generate pattern
	{
		PORTA =  (1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);
		
		PORTA =  (1<<0|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);
		
		PORTA =  (1<<0|1<<1|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);

		PORTA =  (1<<0|1<<1|(1<<2)|(1<<4)|(1<<5)|(1<<6)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);
		
		PORTA =  (1<<0|1<<1|1<<2|(1<<3)|(1<<5)|(1<<6)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);
		
		PORTA =  (1<<0|1<<1|1<<2|(1<<3)|(1<<4)|(1<<6)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);
		
		PORTA =  (1<<0|1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<7));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
		k(x);
		
		PORTA =  ( 1<<0 |1<<1|1<<2|(1<<3)|(1<<5)|(1<<6));
		PORTC =   1<<0 |1<<1|1<<2|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7);
	}

//The function ends here

int main(void)
{
	/*Replace with your application code */
	unsigned char k;
	unsigned char i;
	unsigned char j;
	DDRA=0xFF;//Output
	DDRC=0xFF;//Output
	PORTA=0xFF;//Row
	PORTC=0xFF;//Column//(1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7)
	
	    while (1)
	    {
			//Here is the code
			
		    pattern(1400);
			pattern(1200);
			pattern(1000);
			pattern(800);
			pattern(500);
			pattern(200);
	    }
}