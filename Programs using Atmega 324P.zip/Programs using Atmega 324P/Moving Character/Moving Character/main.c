/*
 * DOT MATRIX Printing Character.c
 *
 * Created: 15-06-2019 16:44:00
 * Author : hp
 */ 

#include <avr/io.h>
#include <util/delay.h>
void gh()
{
  PORTA=0xFF;
  PORTC=0xFF;
  _delay_ms(1);
}

int main(void)
{
	unsigned char k;
	unsigned char i;
	DDRA=0xFF;
	DDRC=0xFF;
	PORTA=0xFF;//Row
	PORTC=0xFF;//Column//(1<<0)|(1<<1)|(1<<2)|(1<<3)|(1<<4)|(1<<5)|(1<<6)|(1<<7)
    /* Replace with your application code */
    while (1) 
    {
					//put delay or dont (Check which one suits up)
					//Algorithm
					
					//Round 1
					
			for(k=0;k<=5;k++)//k for moving character (A) alongside in a marquee
			  
			  {
					for(i=0;i<=20;i++)//Character put in here in loop so as it doesn't distrubs _delay_ms(1);
					{
						
					
					PORTA = 0;//1st Row
					PORTC = (1<<(k));//1 Column   //x=0
					_delay_ms(1);
					gh();
					
					
					PORTA = ~1<<0;// only 1st row selected
					PORTC = 1<<(k+1);//Column   //x=1
					_delay_ms(1);
					
					gh();
					
					PORTA =  (1<<1|1<<2|(1<<3)|(1<<5)|(1<<6)|(1<<6)|(1<<7));//Rows    1<<4 //Special Case to select one row , multiple columns
					PORTC =  (1<<(k+1));//Column //x=1
					_delay_ms(1);
					
					gh();
					
					PORTA = 0;//6th row    1<<4 //Select multiple rows , one column
					PORTC = (1<<(k+2));//Column is always normal   //x=2
					_delay_ms(1);
					
					}
			
			  }
					//Round 2
					
					/*
					
					for(i=0;i<=99;i++) 
					{
					
					PORTA = 0;//1st Row
					PORTC = (1<<1);//1 Column
					_delay_ms(1);
					gh();
					
					
					PORTA = ~1<<0;// only 1st row selected
					PORTC = 1<<2;//Column
					_delay_ms(1);
					
					gh();
					
					PORTA =  (1<<1|1<<2|(1<<3)|(1<<5)|(1<<6)|(1<<6)|(1<<7));//Rows    1<<4 //Special Case to select one row , multiple columns
					PORTC =  (1<<2);//Column
					_delay_ms(1);
					
					gh();
					
					PORTA = 0;//6th row    1<<4 //Select multiple rows , one column
					PORTC = (1<<3);//Column is always normal
					_delay_ms(1);
						
					}
					
					*/
    }
}